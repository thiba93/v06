package org.akov.agence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgenceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgenceApplication.class, args);
    }

}
