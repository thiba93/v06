package org.akov.agence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgenceApplicationTests {

    @Test
    void contextLoads() {
    }

}
